# OpenSanta Game Studio

A .NET 8 Windows Forms game studio with an AI persona named Santa. Both modes read the player's game request. Free mode interprets common themes locally and creates a real playable HTML5 canvas game with no API key. Pro mode sends the same request to Santa through an AI endpoint for a more detailed game implementation, then previews complete HTML responses.

## Run

1. Install the .NET 8 SDK.
2. Run Free mode immediately:

```powershell
dotnet run
```

Describe a game, choose `OpenSanta 1 (Free)`, click `Create Game Code`, then click `Preview Game`. The generated standalone game is saved in `Documents/OpenSanta Games` and can be uploaded to GitHub Pages.

Try prompts such as `Make a space game where I collect stars and avoid aliens`, `Create an underwater pearl game`, or `Make a zombie survival game`. Free mode changes the game instructions, theme, colors, collectibles, and enemies based on the request.

For a real soccer game, use a prompt such as `Make a soccer game`. Free mode creates a pitch with a ball, keeper, goal, ball kicking, and a three-goal win condition.

3. Optional: configure Pro mode with an API key:

```powershell
$env:OPENSANTA_API_KEY = "your-api-key"
```

4. Optionally configure the endpoint, model, and hosted checkout:

```powershell
$env:OPENSANTA_API_URL = "https://api.openai.com/v1/chat/completions"
$env:OPENSANTA_API_MODEL = "gpt-4o-mini"
$env:OPENSANTA_PAYMENT_URL = "https://your-domain.example/checkout"
$env:OPENSANTA_LICENSE_VALIDATION_URL = "https://your-domain.example/api/licenses/validate"
```

5. Run:

```powershell
dotnet run
```

The Buy Pro button requires `OPENSANTA_PAYMENT_URL` to point to your real hosted checkout and `OPENSANTA_LICENSE_VALIDATION_URL` to point to your license server. Do not collect debit-card numbers inside this desktop app; use Stripe Checkout or another PCI-compliant hosted payment page. The app does not add credits to GitHub Copilot: Copilot billing and credits are controlled by GitHub/Microsoft. The payment flow unlocks OpenSanta Pro after your server confirms a valid purchase.

## GitHub publishing

Commit the source files to a GitHub repository. Do not commit `bin/`, `obj/`, API keys, or payment secrets. The generated HTML games are standalone files and can be published with GitHub Pages.
