#nullable enable

using System.Drawing;
using System.Windows.Forms;

namespace OpenSantaGameStudio;

partial class Form1
{
    private System.ComponentModel.IContainer? components = null;
    private Label lblTitle = null!;
    private Label lblModel = null!;
    private ComboBox cmbModel = null!;
    private Button btnUpgrade = null!;
    private TextBox txtPrompt = null!;
    private Button btnGenerate = null!;
    private Button btnPreview = null!;
    private TextBox txtOutput = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            components?.Dispose();
            httpClient.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        lblTitle = new Label();
        lblModel = new Label();
        cmbModel = new ComboBox();
        btnUpgrade = new Button();
        txtPrompt = new TextBox();
        btnGenerate = new Button();
        btnPreview = new Button();
        txtOutput = new TextBox();
        SuspendLayout();

        lblTitle.AutoSize = true;
        lblTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
        lblTitle.Location = new Point(24, 20);
        lblTitle.Name = "lblTitle";
        lblTitle.Size = new Size(306, 37);
        lblTitle.Text = "OpenSanta Game Studio";

        lblModel.AutoSize = true;
        lblModel.Location = new Point(27, 82);
        lblModel.Name = "lblModel";
        lblModel.Size = new Size(48, 15);
        lblModel.Text = "Model:";

        cmbModel.DropDownStyle = ComboBoxStyle.DropDownList;
        cmbModel.FormattingEnabled = true;
        cmbModel.Items.AddRange(["OpenSanta 1 (Free)", "OpenSanta 1 Pro ($2.99)"]);
        cmbModel.Location = new Point(81, 78);
        cmbModel.Name = "cmbModel";
        cmbModel.Size = new Size(220, 23);
        cmbModel.TabIndex = 0;

        btnUpgrade.Location = new Point(312, 77);
        btnUpgrade.Name = "btnUpgrade";
        btnUpgrade.Size = new Size(145, 26);
        btnUpgrade.TabIndex = 1;
        btnUpgrade.Text = "Buy Pro ($2.99)";
        btnUpgrade.UseVisualStyleBackColor = true;
        btnUpgrade.Click += btnUpgrade_Click;

        txtPrompt.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        txtPrompt.Location = new Point(27, 119);
        txtPrompt.Multiline = true;
        txtPrompt.Name = "txtPrompt";
        txtPrompt.PlaceholderText = "Describe the game you want to create...";
        txtPrompt.ScrollBars = ScrollBars.Vertical;
        txtPrompt.Size = new Size(730, 105);
        txtPrompt.TabIndex = 2;

        btnGenerate.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        btnGenerate.Location = new Point(489, 230);
        btnGenerate.Name = "btnGenerate";
        btnGenerate.Size = new Size(163, 32);
        btnGenerate.TabIndex = 3;
        btnGenerate.Text = "Create Game Code";
        btnGenerate.UseVisualStyleBackColor = true;
        btnGenerate.Click += btnGenerate_Click;

        btnPreview.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        btnPreview.Enabled = false;
        btnPreview.Location = new Point(662, 230);
        btnPreview.Name = "btnPreview";
        btnPreview.Size = new Size(95, 32);
        btnPreview.TabIndex = 4;
        btnPreview.Text = "Preview Game";
        btnPreview.UseVisualStyleBackColor = true;
        btnPreview.Click += btnPreview_Click;

        txtOutput.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        txtOutput.Font = new Font("Cascadia Mono", 10F);
        txtOutput.Location = new Point(27, 277);
        txtOutput.Multiline = true;
        txtOutput.Name = "txtOutput";
        txtOutput.ReadOnly = true;
        txtOutput.ScrollBars = ScrollBars.Both;
        txtOutput.Size = new Size(730, 350);
        txtOutput.TabIndex = 5;
        txtOutput.WordWrap = false;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(784, 651);
        Controls.Add(txtOutput);
        Controls.Add(btnPreview);
        Controls.Add(btnGenerate);
        Controls.Add(txtPrompt);
        Controls.Add(btnUpgrade);
        Controls.Add(cmbModel);
        Controls.Add(lblModel);
        Controls.Add(lblTitle);
        MinimumSize = new Size(650, 500);
        Name = "Form1";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "OpenSanta Game Studio";
        ResumeLayout(false);
        PerformLayout();
    }
}
