using System.Drawing;
using System.Windows.Forms;

namespace OpenSantaGameStudio;

public sealed class LicenseKeyDialog : Form
{
    private readonly TextBox txtLicenseKey;

    public string LicenseKey => txtLicenseKey.Text.Trim();

    public LicenseKeyDialog()
    {
        Text = "Activate OpenSanta 1 Pro";
        ClientSize = new Size(420, 150);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        StartPosition = FormStartPosition.CenterParent;
        ShowInTaskbar = false;

        var label = new Label
        {
            AutoSize = true,
            Location = new Point(18, 18),
            Text = "Enter the license key from your purchase:"
        };

        txtLicenseKey = new TextBox
        {
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            Location = new Point(18, 50),
            Size = new Size(384, 27),
            PlaceholderText = "License key"
        };

        var btnCancel = new Button
        {
            Anchor = AnchorStyles.Bottom | AnchorStyles.Right,
            DialogResult = DialogResult.Cancel,
            Location = new Point(232, 100),
            Size = new Size(80, 30),
            Text = "Cancel"
        };

        var btnActivate = new Button
        {
            Anchor = AnchorStyles.Bottom | AnchorStyles.Right,
            DialogResult = DialogResult.OK,
            Location = new Point(320, 100),
            Size = new Size(82, 30),
            Text = "Activate"
        };

        AcceptButton = btnActivate;
        CancelButton = btnCancel;
        Controls.AddRange([label, txtLicenseKey, btnCancel, btnActivate]);
    }
}
