using System.Diagnostics;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace OpenSantaGameStudio;

public partial class Form1 : Form
{
    private const string FreeModel = "OpenSanta 1 (Free)";
    private const string ProModel = "OpenSanta 1 Pro ($2.99)";
    private const string FreeSystemPrompt = "You are OpenSanta 1, a basic game engine assistant. Write simple C# or HTML5 canvas game code.";
    private const string ProSystemPrompt = "You are Santa, the OpenSanta game-building AI. Read the player's game request carefully and implement that exact game. Return one complete, runnable HTML5 canvas game inside a single HTML document, with collision detection, scoring, restart behavior, controls, and assets drawn in code. Do not return a fake placeholder, a design description, or partial code.";

    private readonly HttpClient httpClient = new();
    private bool isProUnlocked;
    private string? generatedGamePath;

    public Form1()
    {
        InitializeComponent();
        cmbModel.SelectedIndex = 0;
        httpClient.Timeout = TimeSpan.FromMinutes(2);
    }

    private async void btnGenerate_Click(object? sender, EventArgs e)
    {
        if (cmbModel.SelectedItem?.ToString() == ProModel && !isProUnlocked)
        {
            MessageBox.Show(
                "OpenSanta 1 Pro requires a $2.99 upgrade. Click Buy Pro to activate.",
                "Upgrade required",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        var prompt = txtPrompt.Text.Trim();
        if (string.IsNullOrWhiteSpace(prompt))
        {
            MessageBox.Show("Describe the game you want to create first.", "Prompt required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtPrompt.Focus();
            return;
        }

        if (cmbModel.SelectedItem?.ToString() == FreeModel)
        {
            var gameHtml = BuildLocalGameHtml(prompt);
            generatedGamePath = SaveGeneratedGame(gameHtml);
            txtOutput.Text = gameHtml;
            btnPreview.Enabled = true;
            MessageBox.Show(
                $"Your playable game was created locally and saved to:\n{generatedGamePath}",
                "Game created",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        var apiKey = Environment.GetEnvironmentVariable("OPENSANTA_API_KEY");
        if (string.IsNullOrWhiteSpace(apiKey))
        {
            MessageBox.Show(
                "Set the OPENSANTA_API_KEY environment variable before generating code.",
                "API key not configured",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        var systemPrompt = cmbModel.SelectedItem?.ToString() == ProModel ? ProSystemPrompt : FreeSystemPrompt;
        var apiUrl = Environment.GetEnvironmentVariable("OPENSANTA_API_URL") ?? "https://api.openai.com/v1/chat/completions";
        var modelName = Environment.GetEnvironmentVariable("OPENSANTA_API_MODEL") ?? "gpt-4o-mini";
        var requestBody = new
        {
            model = modelName,
            messages = new[]
            {
                new { role = "system", content = systemPrompt },
                new { role = "user", content = prompt }
            },
            temperature = 0.7
        };

        SetGeneratingState(true);
        txtOutput.Clear();

        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, apiUrl);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);
            request.Content = new StringContent(JsonConvert.SerializeObject(requestBody), Encoding.UTF8, "application/json");

            using var response = await httpClient.SendAsync(request);
            var responseText = await response.Content.ReadAsStringAsync();
            if (!response.IsSuccessStatusCode)
            {
                throw new InvalidOperationException($"API request failed ({(int)response.StatusCode}): {responseText}");
            }

            var json = JObject.Parse(responseText);
            var generatedCode = json["choices"]?[0]?["message"]?["content"]?.Value<string>();
            if (string.IsNullOrWhiteSpace(generatedCode))
            {
                throw new InvalidOperationException("The API returned no generated code.");
            }

            txtOutput.Text = generatedCode;
            var htmlGame = ExtractHtmlDocument(generatedCode);
            if (htmlGame is not null)
            {
                generatedGamePath = SaveGeneratedGame(htmlGame);
                btnPreview.Enabled = true;
            }
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or InvalidOperationException or JsonException)
        {
            txtOutput.Text = "Generation failed.";
            MessageBox.Show(ex.Message, "Generation error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            SetGeneratingState(false);
        }
    }

        private void btnPreview_Click(object? sender, EventArgs e)
        {
                if (string.IsNullOrWhiteSpace(generatedGamePath) || !File.Exists(generatedGamePath))
                {
                        MessageBox.Show("Create a Free game first.", "Preview unavailable", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                }

                Process.Start(new ProcessStartInfo(generatedGamePath) { UseShellExecute = true });
        }

        private static string SaveGeneratedGame(string html)
        {
                var gamesDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "OpenSanta Games");
                Directory.CreateDirectory(gamesDirectory);
                var fileName = $"opensanta-game-{DateTime.Now:yyyyMMdd-HHmmss}.html";
                var gamePath = Path.Combine(gamesDirectory, fileName);
                File.WriteAllText(gamePath, html, Encoding.UTF8);
                return gamePath;
        }

        private static string BuildLocalGameHtml(string prompt)
        {
                var title = prompt.Length > 48 ? prompt[..48].TrimEnd() + "..." : prompt;
                var safeTitle = JsonConvert.SerializeObject(title);
            var design = GameDesign.FromPrompt(prompt);
                return """
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>__TITLE_TEXT__</title>
    <style>
        :root {{ color-scheme: dark; font-family: system-ui, sans-serif; background: __BACKGROUND__; color: #f3f7ff; }}
        body {{ margin: 0; min-height: 100vh; display: grid; place-items: center; background: radial-gradient(circle at 50% 0%, __ACCENT__, __BACKGROUND__ 60%); }}
        main {{ width: min(94vw, 900px); text-align: center; }}
        h1 {{ margin: 0 0 8px; font-size: clamp(1.3rem, 4vw, 2rem); }}
        p {{ color: #b7c9dc; margin: 0 0 14px; }}
        canvas {{ width: 100%; max-width: 800px; aspect-ratio: 2 / 1; display: block; margin: auto; border: 2px solid __ACCENT__; border-radius: 10px; background: __BACKGROUND__; box-shadow: 0 15px 40px #07101bcc; }}
        button {{ margin-top: 14px; padding: 9px 16px; border: 0; border-radius: 6px; background: __ACCENT__; color: #07101b; font-weight: 700; cursor: pointer; }}
    </style>
</head>
<body>
<main>
    <h1 id="title"></h1>
    <p>__INSTRUCTIONS__ Press R to restart.</p>
    <canvas id="game" width="800" height="400"></canvas>
    <button id="restart">Restart Game</button>
</main>
<script>
const requestedTitle = __TITLE_JSON__;
const collectibleName = __COLLECTIBLE_JSON__;
const enemyName = __ENEMY_JSON__;
const accentColor = '__ACCENT__';
const backgroundColor = '__BACKGROUND__';
let worldSeed = __SEED__;
const collectibleCount = __COLLECTIBLE_COUNT__;
const enemyCount = __ENEMY_COUNT__;
const playerSpeed = __PLAYER_SPEED__;
const enemySpeed = __ENEMY_SPEED__;
const gameMode = '__GAME_MODE__';
document.getElementById('title').textContent = requestedTitle;
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const keys = new Set();
const player = {{ x: 70, y: 200, size: 22, speed: playerSpeed }};
let score = 0, gameOver = false, lastTime = 0;
let gems = [], hunters = [];
let ball = {{ x: 400, y: 200, vx: 0, vy: 0, size: 10 }}, opponent = {{ x: 735, y: 200, size: 28, speed: 2.2 }};
function random() {{ const value = Math.sin(worldSeed++) * 10000; return value - Math.floor(value); }}
function reset() {{
    player.x = 70; player.y = 200; score = 0; gameOver = false;
    ball = {{ x: 400, y: 200, vx: 0, vy: 0, size: 10 }}; opponent.y = 200;
    gems = Array.from({{length: collectibleCount}}, () => ({{ x: 100 + random() * 650, y: 40 + random() * 320 }}));
    hunters = Array.from({{length: enemyCount}}, () => ({{ x: 350 + random() * 400, y: 40 + random() * 320, size: 25, speed: enemySpeed * (0.75 + random() * 0.5) }}));
}}
function hit(a,b) {{ return Math.abs(a.x-b.x) < (a.size || 10) + (b.size || 10) && Math.abs(a.y-b.y) < (a.size || 10) + (b.size || 10); }}
function update(dt) {{
    if (gameOver) return;
    const dx = (keys.has('ArrowRight') || keys.has('d') ? 1 : 0) - (keys.has('ArrowLeft') || keys.has('a') ? 1 : 0);
    const dy = (keys.has('ArrowDown') || keys.has('s') ? 1 : 0) - (keys.has('ArrowUp') || keys.has('w') ? 1 : 0);
    player.x = Math.max(18, Math.min(782, player.x + dx * player.speed * dt * 60));
    player.y = Math.max(18, Math.min(382, player.y + dy * player.speed * dt * 60));
    if (gameMode === 'soccer') {{
        const distance = Math.hypot(player.x - ball.x, player.y - ball.y);
        if (distance < 38) {{ ball.vx = 7; ball.vy = (ball.y - player.y) * 0.18; }}
        ball.x += ball.vx * dt * 60; ball.y += ball.vy * dt * 60; ball.vx *= 0.985; ball.vy *= 0.985;
        ball.y = Math.max(25, Math.min(375, ball.y));
        opponent.y += Math.sign(ball.y - opponent.y) * opponent.speed * dt * 60;
        if (ball.x > 780 && ball.y > 125 && ball.y < 275) {{ score++; ball.x = 400; ball.y = 200; ball.vx = 0; }}
        if (Math.abs(ball.x - opponent.x) < 30 && Math.abs(ball.y - opponent.y) < 38) {{ ball.vx = -6; ball.vy = (ball.y - opponent.y) * 0.2; }}
        if (score >= 3) gameOver = true;
        return;
    }}
    gems = gems.filter(gem => {{ if (hit(player, {{...gem,size:12}})) {{ score += 10; return false; }} return true; }});
    hunters.forEach(hunter => {{ const angle = Math.atan2(player.y-hunter.y, player.x-hunter.x); hunter.x += Math.cos(angle) * hunter.speed * dt * 60; hunter.y += Math.sin(angle) * hunter.speed * dt * 60; if (hit(player,hunter)) gameOver = true; }});
    if (!gems.length) gameOver = true;
}}
function draw() {{
    ctx.clearRect(0,0,800,400); ctx.fillStyle = backgroundColor; ctx.fillRect(0,0,800,400);
    if (gameMode === 'soccer') {{
        ctx.fillStyle='#2d9b55'; ctx.fillRect(0,0,800,400); ctx.strokeStyle='#d9f5df'; ctx.lineWidth=3; ctx.strokeRect(12,12,776,376); ctx.beginPath(); ctx.moveTo(400,12); ctx.lineTo(400,388); ctx.stroke(); ctx.beginPath(); ctx.arc(400,200,60,0,Math.PI*2); ctx.stroke(); ctx.fillStyle='#ef476f'; ctx.fillRect(opponent.x-12,opponent.y-28,24,56); ctx.fillStyle='#f3f7ff'; ctx.fillRect(780,125,8,150); ctx.beginPath(); ctx.arc(ball.x,ball.y,10,0,Math.PI*2); ctx.fill();
    }} else {{
        ctx.strokeStyle = '#253a55'; for (let x=0;x<800;x+=40) {{ ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,400); ctx.stroke(); }}
        gems.forEach(gem => {{ ctx.fillStyle='#ffd166'; ctx.beginPath(); ctx.arc(gem.x,gem.y,10,0,Math.PI*2); ctx.fill(); }});
        hunters.forEach(hunter => {{ ctx.fillStyle='#ef476f'; ctx.fillRect(hunter.x-12,hunter.y-12,24,24); }});
    }}
    ctx.fillStyle=accentColor; ctx.fillRect(player.x-11,player.y-11,22,22);
    ctx.fillStyle='#f3f7ff'; ctx.font='bold 18px system-ui'; ctx.fillText(gameMode === 'soccer' ? 'Goals: '+score+' / 3' : 'Score: '+score,18,30);
    ctx.font='14px system-ui'; ctx.fillText(gameMode === 'soccer' ? 'Touch the ball to shoot. Score 3 goals.' : 'Collect '+collectibleName+'s | Avoid '+enemyName+'s',18,52);
    if (gameOver) {{ ctx.fillStyle='#f3f7ff'; ctx.textAlign='center'; ctx.font='bold 30px system-ui'; ctx.fillText(gems.length ? 'Game Over' : 'You Win!',400,190); ctx.font='16px system-ui'; ctx.fillText('Press R or click Restart Game',400,220); ctx.textAlign='left'; }}
}}
function loop(time) {{ const dt=Math.min((time-lastTime)/1000,0.05); lastTime=time; update(dt); draw(); requestAnimationFrame(loop); }}
addEventListener('keydown', event => {{ keys.add(event.key); if (event.key.toLowerCase()==='r') reset(); }});
addEventListener('keyup', event => keys.delete(event.key));
document.getElementById('restart').onclick=reset; reset(); requestAnimationFrame(loop);
</script>
</body>
</html>
"""
                    .Replace("__TITLE_TEXT__", System.Net.WebUtility.HtmlEncode(title), StringComparison.Ordinal)
                    .Replace("__TITLE_JSON__", safeTitle, StringComparison.Ordinal)
                    .Replace("__INSTRUCTIONS__", System.Net.WebUtility.HtmlEncode(design.Instructions), StringComparison.Ordinal)
                    .Replace("__COLLECTIBLE_JSON__", JsonConvert.SerializeObject(design.Collectible), StringComparison.Ordinal)
                    .Replace("__ENEMY_JSON__", JsonConvert.SerializeObject(design.Enemy), StringComparison.Ordinal)
                    .Replace("__ACCENT__", design.Accent, StringComparison.Ordinal)
                    .Replace("__BACKGROUND__", design.Background, StringComparison.Ordinal)
                    .Replace("__GAME_MODE__", design.GameMode, StringComparison.Ordinal)
                    .Replace("__SEED__", design.Seed.ToString(System.Globalization.CultureInfo.InvariantCulture), StringComparison.Ordinal)
                    .Replace("__COLLECTIBLE_COUNT__", design.CollectibleCount.ToString(System.Globalization.CultureInfo.InvariantCulture), StringComparison.Ordinal)
                    .Replace("__ENEMY_COUNT__", design.EnemyCount.ToString(System.Globalization.CultureInfo.InvariantCulture), StringComparison.Ordinal)
                    .Replace("__PLAYER_SPEED__", design.PlayerSpeed.ToString(System.Globalization.CultureInfo.InvariantCulture), StringComparison.Ordinal)
                    .Replace("__ENEMY_SPEED__", design.EnemySpeed.ToString(System.Globalization.CultureInfo.InvariantCulture), StringComparison.Ordinal)
                    .Replace("{{", "{", StringComparison.Ordinal)
                    .Replace("}}", "}", StringComparison.Ordinal);
        }

    private sealed record GameDesign(string Instructions, string Collectible, string Enemy, string Accent, string Background, string GameMode, int Seed, int CollectibleCount, int EnemyCount, double PlayerSpeed, double EnemySpeed)
    {
        public static GameDesign FromPrompt(string prompt)
        {
            var text = prompt.ToLowerInvariant();
            var seed = Math.Abs(prompt.Aggregate(17, (hash, character) => unchecked(hash * 31 + character)));
            var collectibleCount = 4 + seed % 5;
            var enemyCount = 1 + seed % 3;
            var playerSpeed = 3.2 + seed % 18 / 10.0;
            var enemySpeed = 0.8 + seed % 12 / 10.0;
            if (text.Contains("soccer") || text.Contains("football") || text.Contains("futbol"))
            {
                return new("Touch the ball to shoot. Score three goals against the keeper.", "ball", "keeper", "#f3f7ff", "#2d9b55", "soccer", seed, 0, 0, playerSpeed, enemySpeed);
            }
            if (text.Contains("space") || text.Contains("ship") || text.Contains("galaxy"))
            {
                return new("Pilot your ship with WASD or arrow keys. Collect stars and avoid alien hunters.", "star", "alien", "#68d8c4", "#101827", "collect", seed, collectibleCount + 1, enemyCount + 1, playerSpeed, enemySpeed + 0.2);
            }

            if (text.Contains("ocean") || text.Contains("underwater") || text.Contains("fish"))
            {
                return new("Swim with WASD or arrow keys. Collect pearls and avoid sharks.", "pearl", "shark", "#4cc9f0", "#082f49", "collect", seed, collectibleCount, enemyCount, playerSpeed - 0.2, enemySpeed);
            }

            if (text.Contains("zombie") || text.Contains("survive") || text.Contains("horror"))
            {
                return new("Move with WASD or arrow keys. Collect supplies and survive the zombies.", "supply", "zombie", "#a7c957", "#172016", "collect", seed, collectibleCount + 2, enemyCount + 2, playerSpeed, enemySpeed + 0.3);
            }

            return new("Move with WASD or arrow keys. Collect gold and avoid the red hunters.", "gold", "hunter", "#68d8c4", "#18243a", "collect", seed, collectibleCount, enemyCount, playerSpeed, enemySpeed);
        }
    }

    private static string? ExtractHtmlDocument(string generatedCode)
    {
        var start = generatedCode.IndexOf("<!doctype html", StringComparison.OrdinalIgnoreCase);
        if (start < 0)
        {
            start = generatedCode.IndexOf("<html", StringComparison.OrdinalIgnoreCase);
        }

        var end = generatedCode.LastIndexOf("</html>", StringComparison.OrdinalIgnoreCase);
        return start >= 0 && end > start ? generatedCode[start..(end + "</html>".Length)] : null;
    }

    private async void btnUpgrade_Click(object? sender, EventArgs e)
    {
        var paymentUrl = Environment.GetEnvironmentVariable("OPENSANTA_PAYMENT_URL");
        if (string.IsNullOrWhiteSpace(paymentUrl) || !Uri.TryCreate(paymentUrl, UriKind.Absolute, out var checkoutUri) ||
            (checkoutUri.Scheme != Uri.UriSchemeHttps && checkoutUri.Scheme != Uri.UriSchemeHttp))
        {
            MessageBox.Show(
                "Configure OPENSANTA_PAYMENT_URL with your real Stripe checkout link. A desktop app cannot directly add credits to GitHub Copilot.",
                "Payment setup required",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        try
        {
            Process.Start(new ProcessStartInfo(checkoutUri.AbsoluteUri) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Could not open the payment page: {ex.Message}", "Payment page error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        MessageBox.Show(
            "Complete payment in your browser, then enter the license key issued by your payment server. This unlocks OpenSanta Pro only; it does not add GitHub Copilot credits.",
            "Complete your purchase",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information);

        using var licenseDialog = new LicenseKeyDialog();
        if (licenseDialog.ShowDialog(this) == DialogResult.OK &&
            await ValidateLicenseKeyAsync(licenseDialog.LicenseKey))
        {
            isProUnlocked = true;
            MessageBox.Show("OpenSanta 1 Pro is now unlocked.", "Upgrade successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        else if (licenseDialog.DialogResult == DialogResult.OK)
        {
            MessageBox.Show("That license key is not valid.", "Activation failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private async Task<bool> ValidateLicenseKeyAsync(string licenseKey)
    {
        var validationUrl = Environment.GetEnvironmentVariable("OPENSANTA_LICENSE_VALIDATION_URL");
        if (string.IsNullOrWhiteSpace(validationUrl))
        {
            MessageBox.Show(
                "Configure OPENSANTA_LICENSE_VALIDATION_URL so the app can verify purchases with your server.",
                "License server not configured",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return false;
        }

        using var response = await httpClient.PostAsJsonAsync(validationUrl, new { licenseKey });
        if (!response.IsSuccessStatusCode)
        {
            return false;
        }

        var result = await response.Content.ReadFromJsonAsync<LicenseValidationResponse>();
        return result?.Valid == true;
    }

    private sealed class LicenseValidationResponse
    {
        public bool Valid { get; set; }
    }

    private void SetGeneratingState(bool isGenerating)
    {
        btnGenerate.Enabled = !isGenerating;
        btnUpgrade.Enabled = !isGenerating;
        btnPreview.Enabled = !isGenerating && !string.IsNullOrWhiteSpace(generatedGamePath);
        cmbModel.Enabled = !isGenerating;
        txtPrompt.Enabled = !isGenerating;
        btnGenerate.Text = isGenerating ? "Generating..." : "Create Game Code";
    }
}
